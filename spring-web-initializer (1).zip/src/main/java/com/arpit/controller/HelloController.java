package com.arpit.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Map;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import org.json.JSONObject;

import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	
	//@Resource(name = "keys")
	//private Map<String, String> keys;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	@ResponseBody
	public String showHelloWorld() {
		return "Hello world";
	}
	
	/*
    private static String JDBC_driver = "com.mysql.cj.jdbc.Driver";
    private static String JDBC_URL = "jdbc:mysql://192.169.40.183:3306/scplus?serverTimezone=UTC";
    private static String JDBC_USR = "externo2";
    private static String JDBC_PAS = "Senha@2020";
    private static String SQL_INSERT = "INSERT INTO mensagem (cliente, endpoint, gateway, sensor, data_hora, um_medida, valor) VALUES (?,?,?,?,?,?,?);";        
    private static Connection dbConexao = null;
	
    private static String broker = "tcp://192.169.40.183:1883";
    private static String clientId = "JavaMQTTSync";
    private static String topico = "test";
    private static int qos = 0;


    public static void main(String[] args) {
        
        MemoryPersistence persistence = new MemoryPersistence();

        try {

            try {
            	Class.forName(JDBC_driver);
            	dbConexao = DriverManager.getConnection(JDBC_URL, JDBC_USR, JDBC_PAS); 
            	if (dbConexao != null) {
            		System.out.println("Conexao com o banco MySQL com sucesso!"); 
            	}
            		
	        } catch (Exception me) {
	            if (me instanceof MqttException) {
	                System.out.println("reason " + ((MqttException) me).getReasonCode());
	            }
	            System.out.println("msg " + me.getMessage());
	            System.out.println("loc " + me.getLocalizedMessage());
	            System.out.println("cause " + me.getCause());
	            System.out.println("excep " + me);
	            me.printStackTrace();
	        }

            
            
            try {
	            MqttClient sampleClient1 = new MqttClient(broker, clientId, persistence);
	            MqttConnectOptions connOpts1 = new MqttConnectOptions();
	            connOpts1.setCleanSession(true);
	            
	            System.out.println(clientId + " Conectando do broker: " + broker);
	            sampleClient1.connect(connOpts1);        
	            
	            String content1 = clientId + " Conectado ao MqttMosquitto";        
	            MqttMessage message = new MqttMessage(content1.getBytes());
	            message.setQos(qos);//vezes enviada
	            sampleClient1.publish(topico, message);            
	            sampleClient1.disconnect();
	            
	        } catch (Exception me) {
	            if (me instanceof MqttException) {
	                System.out.println("reason " + ((MqttException) me).getReasonCode());
	            }
	            System.out.println("msg " + me.getMessage());
	            System.out.println("loc " + me.getLocalizedMessage());
	            System.out.println("cause " + me.getCause());
	            System.out.println("excep " + me);
	            me.printStackTrace();
	        }         
            
            

            try {
                MqttAsyncClient sampleClient = new MqttAsyncClient(broker, clientId, persistence);
                MqttConnectOptions connOpts = new MqttConnectOptions();            
                connOpts.setCleanSession(true);
                
	            System.out.println(clientId + " Conectando ao broker: " + broker);
	            sampleClient.connect(connOpts);
	            
	            System.out.println(clientId + " Conectado ao broker: " + broker);
	            System.out.println("");
	            
	            sampleClient.setCallback(new MqttCallback() {
					
					@Override
					public void messageArrived(String topic, MqttMessage message) throws Exception {
				        try {
				        	byte[] payload = message.getPayload(); 

				            if (payload[0] != 111) {
				                System.out.println("Recebendo");
				                System.out.println("topico: " + topic);
				                
					            JSONObject val = new JSONObject(new String(message.getPayload()));
				                System.out.println(val);

				                String cliente = val.get("cliente").toString();
				                System.out.println(cliente);
				                String endpoint = val.get("endpoint").toString();
				                System.out.println(endpoint);
				                String gateway = val.get("gateway").toString();
				                System.out.println(gateway);
				                String sensor = val.get("sensor").toString();
				                System.out.println(sensor);
				                String data_hora = val.get("data_hora").toString();
				                System.out.println(data_hora);
				                String um_medida = val.get("um_medida").toString();
				                System.out.println(um_medida);
				                String valor = val.get("valor").toString();
				                System.out.println(valor);
					            System.out.println("");

					            float valor2 = Float.valueOf(valor);
					            
				                if (dbConexao != null) {                   	
					                try { 
					                    PreparedStatement stmt = dbConexao.prepareStatement(SQL_INSERT);
					                    stmt.setString(1, cliente);
						                stmt.setString(2, endpoint);
						                stmt.setString(3, gateway);
						                stmt.setString(4, sensor);
						                stmt.setString(5, data_hora);
						                stmt.setString(6, um_medida);
						                stmt.setFloat(7, valor2);
					                    stmt.execute();
					                    
					                    stmt.close();
					    	        } catch (Exception me) {
					    	            if (me instanceof MqttException) {
					    	                System.out.println("reason " + ((MqttException) me).getReasonCode());
					    	            }
					    	            System.out.println("msg " + me.getMessage());
					    	            System.out.println("loc " + me.getLocalizedMessage());
					    	            System.out.println("cause " + me.getCause());
					    	            System.out.println("excep " + me);
					    	            me.printStackTrace();
					    	        }
					                
						            System.out.println("Gravacao no banco MySQL com sucesso!");
				                }
					            
					        }

		    	        } catch (Exception me) {
		    	            if (me instanceof MqttException) {
		    	                System.out.println("reason " + ((MqttException) me).getReasonCode());
		    	            }
		    	            System.out.println("msg " + me.getMessage());
		    	            System.out.println("loc " + me.getLocalizedMessage());
		    	            System.out.println("cause " + me.getCause());
		    	            System.out.println("excep " + me);
		    	            me.printStackTrace();
		    	        }
						
					}
					
					@Override
					public void deliveryComplete(IMqttDeliveryToken token) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void connectionLost(Throwable cause) {
						// TODO Auto-generated method stub
						
					}
				});
	            
	            while (true) {
		            Thread.sleep(1000);
		            sampleClient.subscribe(topico, qos);
	            }   
            
	        } catch (Exception me) {
	            if (me instanceof MqttException) {
	                System.out.println("reason " + ((MqttException) me).getReasonCode());
	            }
	            System.out.println("msg " + me.getMessage());
	            System.out.println("loc " + me.getLocalizedMessage());
	            System.out.println("cause " + me.getCause());
	            System.out.println("excep " + me);
	            me.printStackTrace();
	        }         
            
            
        } catch (Exception me) {
            if (me instanceof MqttException) {
                System.out.println("reason " + ((MqttException) me).getReasonCode());
            }
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }
    }
    */
}
